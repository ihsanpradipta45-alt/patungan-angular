import { Component, computed, signal } from '@angular/core';
import { BudgetBar } from './components/budget-bar';
import { ExpenseCard } from './components/expense-card';
import { BUDGET, EXPENSES } from './data/expenses';

@Component({
  selector: 'app-root',
  imports: [BudgetBar, ExpenseCard],
  templateUrl: './app.html',
})
export class App {
  protected readonly budget = BUDGET;
  protected readonly expenses = signal(EXPENSES);

  protected readonly totalSpent = computed(() =>
    this.expenses().reduce((sum, e) => sum + e.amount, 0)
  );

  protected hapus(id: number) {
    this.expenses.update(list => list.filter(e => e.id !== id));
  }
}