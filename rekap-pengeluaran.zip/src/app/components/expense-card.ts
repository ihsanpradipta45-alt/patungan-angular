import { Component, computed, input, output } from '@angular/core';
import { CurrencyPipe, DatePipe, TitleCasePipe } from '@angular/common';
import { Category, Expense } from '../data/expenses';

const CATEGORY_COLOR: Record<Category, string> = {
  makan: 'bg-warning text-dark',
  transport: 'bg-info text-dark',
  belanja: 'bg-primary',
  hiburan: 'bg-secondary',
  tagihan: 'bg-danger',
};

@Component({
  selector: 'app-expense-card',
  imports: [CurrencyPipe, DatePipe, TitleCasePipe],
  templateUrl: './expense-card.html',
  styleUrl: './expense-card.css',
})
export class ExpenseCard {
  expense = input.required<Expense>();
  hapus = output<number>(); // emit id ke parent

  badgeClass = computed(() => CATEGORY_COLOR[this.expense().category]);
}